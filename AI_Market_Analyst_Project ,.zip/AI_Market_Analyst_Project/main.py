import os
import json
from flask import Flask, render_template, request
from PyPDF2 import PdfReader
from google import genai

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# -----------------------------
# PDF TEXT EXTRACTION
# -----------------------------
def extract_text_from_pdf(filepath):
    try:
        reader = PdfReader(filepath)
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
        return text.strip()
    except Exception as e:
        return ""


# -----------------------------
# GEMINI ANALYSIS FUNCTION
# -----------------------------
def analyze_with_gemini(api_key, pdf_text):
    try:
        client = genai.Client(api_key=api_key)

        if not pdf_text:
            return {"error": "Could not extract text from PDF."}

        prompt = f"""
You are a professional Market Research Analyst.
Analyze the business report below.
Respond ONLY with valid JSON.
Do NOT add explanations.
Do NOT use markdown.

Format:
{{
  "current_business_situation": "string",
  "strong_points": ["point1","point2","point3"],
  "weak_points": ["point1","point2","point3"],
  "suggestions_for_improvement": ["suggestion1","suggestion2","suggestion3"],
  "next_strategic_moves": ["move1","move2","move3"]
}}

Business Report:
{pdf_text[:15000]}
"""

        # ✅ CORRECT MODEL NAME
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )

        raw_text = response.text.strip()
        cleaned = raw_text.replace("```json", "").replace("```", "").strip()

        return json.loads(cleaned)

    except Exception as e:
        print(f"Gemini Analysis Error: {e}")
        return {"error": str(e)}


# -----------------------------
# ROUTES
# -----------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        api_key = request.form.get("api_key")
        file = request.files.get("pdf_file")

        if not api_key or not file:
            return render_template("index.html", error="API key and PDF required.")

        filepath = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filepath)

        pdf_text = extract_text_from_pdf(filepath)
        result = analyze_with_gemini(api_key, pdf_text)

        return render_template("dashboard.html", data=json.dumps(result))

    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)